import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home/home.component';
import { SmartphonesComponent } from './smartphones/smartphones.component';

const routes: Routes = [
  {path:'phone',component:SmartphonesComponent},
  {path:'phones/:id/:image/:name/:brand/:price/:ram/:memory/:colour',component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
