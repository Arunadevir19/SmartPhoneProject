import { Component } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  public phnId:any;
  public phnImage:any;
  public phnName:any;
  public phnBrand:any;
  public phnPrice:any;
  public phnRam:any;
  public phnMemory:any;
  public phnColour:any;

  constructor(private route: ActivatedRoute)
  {}
  ngOnInit()
  {
    let id=this.route.snapshot.paramMap.get('id');
    this.phnId=id;
    let image=this.route.snapshot.paramMap.get('image');
    this.phnImage=image;
    let name=this.route.snapshot.paramMap.get('name');
    this.phnName=name;
    let brand=this.route.snapshot.paramMap.get('brand');
    this.phnBrand=brand;
    let price=this.route.snapshot.paramMap.get('price');
    this.phnPrice=price;
    let ram=this.route.snapshot.paramMap.get('ram');
    this.phnRam=ram;
    let memory=this.route.snapshot.paramMap.get('memory');
    this.phnMemory=memory;
    let colour=this.route.snapshot.paramMap.get('colour');
    this.phnColour=colour;
  }

}
