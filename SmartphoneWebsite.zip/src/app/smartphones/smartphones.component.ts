import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ApiserviceService } from '../shared/apiservice.service';
import {PhoneModel} from './smartphones.model';
@Component({
  selector: 'app-smartphones',
  templateUrl: './smartphones.component.html',
  styleUrls: ['./smartphones.component.css']
})
export class SmartphonesComponent {
  formValue !: FormGroup;
  phoneModelObj :PhoneModel=new PhoneModel();
  phoneData: any;
  showAdd !:boolean;
  showUpdate !:boolean;
 
  constructor(private formBuilder: FormBuilder,
    private api: ApiserviceService,
    private router: Router) 
    {

  }
  fetchPhone(phones:any)
  {
    this.router.navigate(['/phones',phones.id,phones.image,phones.name,phones.brand,phones.price,phones.ram,phones.memory,phones.colour]);
  }
  ngOnInit() {
    this.router.routeReuseStrategy.shouldReuseRoute=()=>false;
    this.formValue = this.formBuilder.group({
      id: [''],
      image: [''],
      name: [''],
      brand: [''],
      price: [''],
      ram: [''],
      memory: [''],
      colour: ['']
    })
    this.getAllPhones();
  }
  clickAddPhone()
  {
    this.formValue.reset();
    this.showAdd=true;
    this.showUpdate=false;


  }
  postPhoneDetails()
  {
    this.phoneModelObj.id=this.formValue.value.id;
    this.phoneModelObj.image=this.formValue.value.image;
    this.phoneModelObj.name=this.formValue.value.name;
    this.phoneModelObj.brand=this.formValue.value.brand;
    this.phoneModelObj.price=this.formValue.value.price;
    this.phoneModelObj.ram=this.formValue.value.ram;
    this.phoneModelObj.memory=this.formValue.value.memory;
    this.phoneModelObj.colour=this.formValue.value.colour;

    this.api.postPhones(this.phoneModelObj).subscribe(
      res=>{
        console.log(res);
        alert("Mobile Added Successfully!!!");
        this.getAllPhones();
        let close=document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
      },
      err => {
        alert("Something went wrong!!!");
      }
      )
  }
  getAllPhones() 
  {
    this.api.getAllPhones().subscribe(
      res => {
        this.phoneData = res;
      }
    )
  }
  deletePhone(phn:any)
  {
    this.api.deletePhone(phn.id).subscribe(
      res => {
        alert("Phone Deleted");
        this.getAllPhones();
      }
    )
  }
  editPhoneDetails(data:any)
  {
    
      
    this.phoneModelObj.id=data.id;
    this.showAdd=false;
    this.showUpdate=true;
    this.formValue.controls['id'].setValue(data.id);
    this.formValue.controls['image'].setValue(data.image);
    this.formValue.controls['name'].setValue(data.name);
    this.formValue.controls['brand'].setValue(data.brand);
    this.formValue.controls['price'].setValue(data.price);
    this.formValue.controls['ram'].setValue(data.ram);
    this.formValue.controls['memory'].setValue(data.memory);
    this.formValue.controls['colour'].setValue(data.colour);
  }
  updatePhoneDetails()
  {
    this.phoneModelObj.id=this.formValue.value.id;
    this.phoneModelObj.image=this.formValue.value.image;
    this.phoneModelObj.name=this.formValue.value.name;
    this.phoneModelObj.brand=this.formValue.value.brand;
    this.phoneModelObj.price=this.formValue.value.price;
    this.phoneModelObj.ram=this.formValue.value.ram;
    this.phoneModelObj.memory=this.formValue.value.memory;
    this.phoneModelObj.colour=this.formValue.value.colour;
    this.api.updatePhone(this.phoneModelObj,this.phoneModelObj.id).subscribe(
      res=>{
        console.log(res);
        alert("Mobile Updated Successfully!!!");
        this.getAllPhones();
        let close=document.getElementById("cancel");
        close?.click();
        this.formValue.reset();
      },
      err => {
        alert("Something went wrong!!!");
      }
      )
  }

}
