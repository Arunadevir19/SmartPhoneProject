
export class PhoneModel{
    id:number =0;
    image:string='';
    name:string='';
    brand:string='';
    price:string='';
    ram:string='';
    memory:string='';
    colour:string='';
}